export interface ISale {
  id?: number;
  name?: string;
  price?: number;
  description?: string;
}

export class Sale implements ISale {
  constructor(
    public id?: number,
    public name?: string,
    public price?: number,
    public description?: string
  ) {
  }
}
