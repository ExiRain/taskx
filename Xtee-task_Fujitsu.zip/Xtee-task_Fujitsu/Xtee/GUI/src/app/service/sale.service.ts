import {Injectable} from '@angular/core';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {catchError, Observable} from 'rxjs';

import {ISale} from "../model/sale.model";
import {environment} from "../../environments/environment";
import {ErrorHandlingService} from "./error.service";

type EntityResponseType = HttpResponse<ISale>;
type ArrayResponseType = HttpResponse<ISale[]>;
type EmptyResponseType = HttpResponse<{}>;

@Injectable({providedIn: 'root'})
export class SaleService {
  private v1 = '/v1/sale';
  private apiUrl = environment.apiUrl + this.v1;

  constructor(protected http: HttpClient, private errorHandlingService: ErrorHandlingService) {
  }

  getAllSales(): Observable<ArrayResponseType> {
    return this.http.get<ISale[]>(`${this.apiUrl}/all`, {
      observe: 'response'
    }).pipe(
      catchError(this.errorHandlingService.handleError)
    );
  }

  addSale(sale: ISale): Observable<EntityResponseType> {
    return this.http.post<ISale>(`${this.apiUrl}/add`, sale, {
      observe: 'response'
    }).pipe(
      catchError(this.errorHandlingService.handleError)
    );
  }

  updateSale(sale: ISale): Observable<EntityResponseType> {
    return this.http.put<ISale>(`${this.apiUrl}/update`, sale, {
      observe: 'response'
    }).pipe(
      catchError(this.errorHandlingService.handleError)
    );
  }

  deleteSale(id: number): Observable<EmptyResponseType> {
    return this.http.delete(`${this.apiUrl}/delete/${id}`, {
      observe: 'response'
    }).pipe(
      catchError(this.errorHandlingService.handleError)
    );
  }

  search(keyword: string): Observable<ArrayResponseType> {
    return this.http.get<ISale[]>(`${this.apiUrl}/search/entity?keyword=${keyword}`, {
      observe: 'response'
    }).pipe(
      catchError(this.errorHandlingService.handleError)
    );
  }

  queryData(keyword: string): Observable<ArrayResponseType> {
    if (keyword && keyword.trim().length > 0) {
      return this.search(keyword);
    } else {
      return this.getAllSales();
    }
  }
}
