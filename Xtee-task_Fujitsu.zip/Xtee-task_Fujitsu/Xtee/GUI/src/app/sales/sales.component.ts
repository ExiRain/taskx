import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import {HttpClient, HttpResponse} from '@angular/common/http';
import {CommonModule} from "@angular/common";
import {ISale, Sale} from "../model/sale.model";
import {SaleService} from "../service/sale.service";
import {catchError, Observable, of, tap} from "rxjs";

@Component({
  selector: 'app-sales',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    FormsModule
  ],
  templateUrl: './sales.component.html',
  styleUrl: './sales.component.scss'
})
export class SalesComponent implements OnInit {
  editForm: FormGroup;
  sales: ISale[] = [];
  searchKeyWord: string = '';

  constructor(private fb: FormBuilder, private http: HttpClient, private saleService: SaleService) {
    this.editForm = this.fb.group({
      id: [''],
      name: ['', Validators.required],
      description: ['', Validators.required],
      price: [null, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    this.saleService.queryData(this.searchKeyWord).pipe(
      tap((res: HttpResponse<ISale[]>) => {
        if (res.body) {
          this.sales = res.body;
        }
      }),
      catchError(err => {
        console.error(err);
        return of(null);
      })
    ).subscribe();
  }

  editSale(sale: ISale): void {
    this.updateForm(sale);
  }

  deleteSale(saleId: number): void {
    this.saleService.deleteSale(saleId).subscribe(
      (res) => {
        if (res.status === 204) {
          this.fetchData();
        }
      }, (err) => {
        console.error('Deletion proccess was interupted: ', err)
      });
  }

  save(): void {
    const sale = this.createFromForm();
    if (sale.id !== undefined && sale.id > 0) {
      this.subscribeToSaveResponse(this.saleService.updateSale(sale));
    } else {
      this.subscribeToSaveResponse(this.saleService.addSale(sale));
    }
    this.resetForm();
    this.fetchData();
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<ISale>>): void {
    result.pipe(
      tap(res => this.onSaveSuccess(res)),
      catchError(error => {
        this.onSaveError();
        return of(null);
      })
    ).subscribe();
  }

  protected onSaveSuccess(res: HttpResponse<ISale>): void {
    const body = res.body;
    this.fetchData();
  }

  protected onSaveError(): void {
  }

  protected updateForm(sale: ISale): void {
    this.editForm.patchValue({
      id: sale.id,
      name: sale.name,
      price: sale.price,
      description: sale.description
    });
  }

  private createFromForm(): ISale {
    return {
      ...new Sale(),
      id: this.editForm.get(['id'])!.value,
      name: this.editForm.get(['name'])!.value,
      description: this.editForm.get(['description'])!.value,
      price: this.editForm.get(['price'])!.value
    };
  }

  private resetForm(): void {
    this.editForm.reset();
  }

  search(): void {
    this.saleService.search(this.searchKeyWord).subscribe(res => {
      if (res.body) {
        this.sales = res.body;
      }
    })
  }

  clearSearch(): void {
    this.searchKeyWord = '';
    this.fetchData();
  }
}
