export const environment = {
  production: false,
  apiUrl: 'https://localhost:8080/api'
};
