## Gui module

Author: `Vassili Moskaljov`.

### Installation and usage:
1. In order to run locally you would ned to run few commands from GUI folder:
   * Install all necessary dependencies : `npm install --legacy-peer-deps`
   * After its done we can run the application with: `ng serve --ssl`

2. In order to run module via docker we can build an image and use it to run:
   * Build docker image: `docker built -t <image_name> .` 
   * To run generated image: `docker run -d -p 4200:4200 --name <container_name> <image_name>`

After doing initialization part, you can access module in browser following: https://localhost:4200

Could be used an image, to build an image use this command : `docker build -t <image_name> .`
