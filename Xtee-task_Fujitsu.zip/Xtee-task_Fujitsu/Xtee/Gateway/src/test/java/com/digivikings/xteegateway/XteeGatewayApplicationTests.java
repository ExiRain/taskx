package com.digivikings.xteegateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XteeGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
