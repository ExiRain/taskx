package com.digivikings.xteegateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XteeGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(XteeGatewayApplication.class, args);
    }
}
