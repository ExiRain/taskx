package com.digivikings.xteeservicesales.service.impl;

import com.digivikings.xteeservicesales.model.Sale;
import com.digivikings.xteeservicesales.repository.SaleRepository;
import com.digivikings.xteeservicesales.repository.SearchableRepository;
import com.digivikings.xteeservicesales.service.SaleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SaleServiceImpl extends SearchableServiceImpl<Sale, Sale> implements SaleService {

    private final Logger log = LoggerFactory.getLogger(SaleServiceImpl.class);
    private final SaleRepository repository;

    protected SaleServiceImpl(SearchableRepository<Sale> repository, SaleRepository repository1) {
        super(repository);
        this.repository = repository1;
    }


    @Override
    public List<Sale> getAllSales() {
        List<Sale> response = repository.findAll();
        log.debug("Response for get all sales : {}", response);
        return response;
    }

    @Override
    public List<Sale> searchSales(String name) {
        log.debug("Service searching Sale by name: {}", name);
        return repository.search(name);
    }

    @Override
    public Sale create(Sale sale) {
        log.debug("Service create sale {}", sale);
        return repository.save(sale);
    }

    @Override
    public Sale update(Sale sale) {
        log.debug("Service update sale {}", sale);
        return repository.save(sale);
    }

    @Override
    public void delete(Sale sale) {
        log.debug("Service delete sale {}", sale);
        repository.delete(sale);
    }

    @Override
    public void deleteById(Long id) {
        log.debug("Service delete by id saleId: {}", id);
        repository.deleteById(id);
    }
}
