package com.digivikings.xteeservicesales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XteeServiceSalesApplication {

    public static void main(String[] args) {
        SpringApplication.run(XteeServiceSalesApplication.class, args);
    }

}
