package com.digivikings.xteeservicesales.repository;

import com.digivikings.xteeservicesales.model.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SaleRepository extends JpaRepository<Sale, Long>, SearchableRepository<Sale> {
    @Override
    @Query("select s from sale s where UPPER(s.name) like :keyword")
    List<Sale> search(String keyword);
}
