package com.digivikings.xteeservicesales.service;

import java.util.List;

public interface SearchableService<D,E> {
    List<E> search(String keyword);
}
