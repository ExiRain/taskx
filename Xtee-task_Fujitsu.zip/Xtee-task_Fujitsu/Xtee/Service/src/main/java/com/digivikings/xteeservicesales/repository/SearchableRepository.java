package com.digivikings.xteeservicesales.repository;

import java.util.List;

public interface SearchableRepository<E> {
    List<E> search(String keyword);
}
