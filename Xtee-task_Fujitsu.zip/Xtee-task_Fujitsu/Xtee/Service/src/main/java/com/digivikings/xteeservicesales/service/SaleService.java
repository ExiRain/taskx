package com.digivikings.xteeservicesales.service;

import com.digivikings.xteeservicesales.model.Sale;

import java.util.List;

public interface SaleService extends SearchableService<Sale,Sale>{
    List<Sale> getAllSales();
    List<Sale> searchSales(String name);
    Sale create(Sale sale);
    Sale update(Sale sale);
    void delete(Sale sale);
    void deleteById(Long id);
}
