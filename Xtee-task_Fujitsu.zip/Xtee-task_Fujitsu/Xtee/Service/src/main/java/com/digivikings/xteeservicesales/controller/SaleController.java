package com.digivikings.xteeservicesales.controller;

import com.digivikings.xteeservicesales.model.Sale;
import com.digivikings.xteeservicesales.service.SaleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Log4j2
@RequestMapping("/api/v1/sale")
@Tag(name = "Sale Book api v1", description = "This is version 1 for sales api, covering base crud operations with search by keyword.")
public class SaleController extends SearchableController<Sale> {
    private final SaleService saleService;

    public SaleController(SaleService saleService) {
        super(saleService);
        this.saleService = saleService;
    }

    @Operation(summary = "Get all Sale records from db.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Will return collection of objects if any found or empty array if none is present.",
            content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = Sale[].class))
            })
    })
    @GetMapping("/all")
    public ResponseEntity<List<Sale>> getAllSales() {
        log.debug("Rest request to get all sales.");
        return ResponseEntity.ok(saleService.getAllSales());
    }

    @Operation(summary = "Create a new Sale record")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
        description = "Example of request body to create new sale record.",
        required = true,
        content = @Content(
            schema = @Schema(implementation = Sale.class),
            mediaType = MediaType.APPLICATION_JSON_VALUE,
            examples = {
                @ExampleObject(
                    name = "New sale should contain name, price and description.Null values are not allowed",
                    value = "{" +
                        "name: 'Blue Earrings.', " +
                        "price: 99.99, " +
                        "description: 'Fit for any occasion.'}",
                    summary = "New Sale object example."
                )
            }
        )
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Will return created Sale.",
            content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = Sale.class))
            }),
        @ApiResponse(responseCode = "400", description = "Bad request.Error means request body is null or incorrect.")
    })
    @PostMapping("/add")
    public ResponseEntity<Sale> addSale(@RequestBody Sale sale) {
        log.debug("Rest request to create new sale: {}", sale);
        if(sale == null) {
            return ResponseEntity.badRequest().body(new Sale());
        }
        return ResponseEntity.ok(saleService.create(sale));
    }

    @Operation(summary = "Update an existing Sale record.")
    @io.swagger.v3.oas.annotations.parameters.RequestBody(
        description = "Details of item kek",
        required = true,
        content = @Content(
            schema = @Schema(implementation = Sale.class),
            mediaType = MediaType.APPLICATION_JSON_VALUE,
            examples = {
                @ExampleObject(
                    name = "Updating and existing sale record, must provide existing object with all mandatory fields: id, name, description, price",
                    value = "{" +
                        "id: 1, " +
                        "name: 'Blue Earrings.', " +
                        "price: 99.99, " +
                        "description: 'Fit for any occasion.'}",
                    summary = "Update Existing Sale object."
                )
            }
        )
    )
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Will return updated Sale.",
            content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = Sale.class))
            }),
        @ApiResponse(responseCode = "400", description = "Will return empty Sale object.Error means object was null or formed incorrectly.")
    })
    @PutMapping("/update")
    public ResponseEntity<Sale> updateSale(@RequestBody Sale sale) {
        log.debug("Rest request to update sale: {}", sale);
        if (sale == null) {
            return ResponseEntity.badRequest().body(new Sale());
        }
        return ResponseEntity.ok(saleService.update(sale));
    }

    @Operation(summary = "Delete an existing Sale by ID if exists.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "No content."),
        @ApiResponse(responseCode = "400", description = "Bad request.Error means provided ID is null or negative.")
    })
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteSale(@Parameter(description = "ID of the sale to be deleted.") @PathVariable Long id) {
        log.debug("Rest request to delete sale by id: {}", id);
        if (id == null || id <= 0) {
            return ResponseEntity.badRequest().build();
        }
        saleService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
