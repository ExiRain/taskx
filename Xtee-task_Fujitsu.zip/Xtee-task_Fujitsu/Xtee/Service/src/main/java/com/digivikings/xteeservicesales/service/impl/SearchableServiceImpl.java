package com.digivikings.xteeservicesales.service.impl;

import com.digivikings.xteeservicesales.repository.SearchableRepository;
import com.digivikings.xteeservicesales.service.SearchableService;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public abstract class SearchableServiceImpl<D, E> implements SearchableService<D, E> {
    private final SearchableRepository<E> repository;

    protected SearchableServiceImpl(SearchableRepository<E> repository) {
        this.repository = repository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<E> search(String keyword) {
        String wrappedKeyword = String.format("%%%s%%", keyword.toUpperCase());
        return repository.search(wrappedKeyword);
    }
}
