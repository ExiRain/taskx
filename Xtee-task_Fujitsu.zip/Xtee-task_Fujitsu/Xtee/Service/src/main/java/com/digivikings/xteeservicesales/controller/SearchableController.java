package com.digivikings.xteeservicesales.controller;

import com.digivikings.xteeservicesales.model.Sale;
import com.digivikings.xteeservicesales.service.SearchableService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.log4j.Log4j2;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Log4j2
public abstract class SearchableController<D> {
    private final SearchableService searchableService;


    protected SearchableController(SearchableService searchableService) {
        this.searchableService = searchableService;
    }

    @Operation(summary = "Search for objects by specified keyword.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Will return collection of objects if any found or empty array if none is present.",
            content = {
                @Content(mediaType = "application/json", schema = @Schema(implementation = Sale[].class))
            }),
        @ApiResponse(responseCode = "500", description = "Internal server error")
    })
    @GetMapping("/search/entity")
    public ResponseEntity<List<D>> search(@Parameter(description = "Keyword by which search would be done.") @RequestParam("keyword") String keyword) {
        log.info("Search for objects by specified keyword: {}", keyword);
        return ResponseEntity.ok().body(searchableService.search(keyword));
    }
}
