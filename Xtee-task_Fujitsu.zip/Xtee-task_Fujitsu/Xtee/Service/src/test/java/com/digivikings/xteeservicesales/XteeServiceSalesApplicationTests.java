package com.digivikings.xteeservicesales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XteeServiceSalesApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
