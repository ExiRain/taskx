## Xtee Test assignment

 Author: `Vassili Moskaljov`

### Project structure, and description:
Project consists of 3 modules, for simplicity of running it, they were brought together under 
one directory.If needed could be easily split for separate modules, every folder ready to be 
standalone application.Docker related configurations are located in `.env` file in root of the project.


* Gateway (Java 17 Eclipse Temurin Alpine)
    * Main entry point for application.
    * mTLS authentication
* Microservice (Java 17 Eclipse Temurin Alpine)
  * Serving rest endpoints
  * mTLS authentication
* GUI (Angular 17)
  * Frontend application providing graphical interface
  * By default, runs on port 4200
  * TLS authentication.
* Postgres (14 alpine)
  * Database to store information provided by GUI.
  * mTls authentication.

### Brief GUI description

---

* Application will provide you with page to store objects of type `Sale` which have
  3 fields Name,Description,Price.
* You can enter values and click save to start working with the application.
  * All the fields are mandatory to fill.
* After you have at least one record you would be able to modify it, click 'EDIT' button
  on the right side of a record and the for would be filled with data of current record.Adjust information
  as needed and hit save to update current Sale record.
* Click 'X' button on the right side of the Sale record to delete it.
* Using search:
    * Search would look for any record that have provided 'KEYWORD' string in its name.Enter some characters and hit
      search.List would be provided if found any.
    * To reset search and return to full view, click 'CLEAR' button.

---
### Running project.

To start the project:
1. From root directory of project `~/Xtee` run this command: `docker-compose up -d --build`.
This would build all necessary containers and initialize them.
2. Wait until all containers are initialized and applications fully started.
   1. To check the status of container use this command: `docker logs <container_name>`.
3. Installing the certificate:
   1. In order to get proper access we would need to install certificate.Certificates are located in 
`Xtee/crt` folder, to install in on Linux system we will use this command: 
      1. Navigate to crt folder `cd crt`
      2. Run import command `sudo keytool -import -alias gateway -file gateway.pem -keystore $JAVA_HOME/lib/security/cacerts -storepass changeit`
      3. Note that if $JAVA_HOME is not set, you would have to provide path to it.
      4. On windows machine double click on client.p12 and install it, password : digivikings.
   2. Additionally, we can add client certification to the browser:
      1. Firefox Settings -> Privacy&Security tab -> scroll down till you see 'View Certificates'
button. Click 'Your Certificates' -> Import and provide path to `client.p12` in Xtee/crt folder.Pass is : `digivikings`
      2. Chrome Settings -> Privacy and Security -> Security -> Manage Certificates -> Import, provide path
to `client.p12` in `Xtee/crt` folder.Pass is : `digivikings`
4. To access GUI, open this link: `https://localhost:4200` you will be prompted that resource you are trying to access is not secure,
that is because of certificates being self-signed.To proceed click -> Advanced -> Agree and Proceed.


### Rest API DOCS.

* Project includes openapi documentation with swagger, to access documentation:
  * Run the application.
  * Access documentation via this url: `https://localhost:8090/swagger-ui/index.html`

### Logs
* Logs are being written to log folder and displayed in the console
* Inside docker logs are accessible by path: `/workspace/app/logs/service.log`
  * To inspect logs via command `docker exec -it <container_name> cat /workspace/logs/service.log` for microservice
  * To inspect logs via command `docker exec -it <container_name> cat /workspace/logs/gatway.log` for gateway
* Directly checking logs from container:
  * To have a snapshot of latest state in logs: `docker logs <container_name>`
  * To have session following changes in logs: `docker logs -f <container_name>`



---

Thank you for reading.
